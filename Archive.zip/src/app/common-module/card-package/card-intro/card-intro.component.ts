import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-card-intro',
  templateUrl: './card-intro.component.html',
  styleUrls: ['./card-intro.component.scss']
})
export class CardIntroComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
