import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FillterOneComponent } from './fillter-one.component';



@NgModule({
  declarations: [FillterOneComponent],
  imports: [
    CommonModule
  ],
  exports: [
    FillterOneComponent
  ]
})
export class FillterOneModule { }
