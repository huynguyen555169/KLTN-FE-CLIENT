import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'app-fillter-one',
  templateUrl: './fillter-one.component.html',
  styleUrls: ['./fillter-one.component.scss']
})
export class FillterOneComponent implements OnInit {

  @Input() data: any;
  constructor() { }

  ngOnInit(): void {
  }

}
