import { PostfixPipe } from './postfix.pipe';

describe('PostfixPipe', () => {
  it('create an instance', () => {
    const pipe = new PostfixPipe();
    expect(pipe).toBeTruthy();
  });
});
