export const data = [
    {
        type_name: 'Áo sơ mi',
        type_total: 20,
    },
    {
        type_name: 'Áo thun',
        type_total: 20,
    },
    {
        type_name: 'Quần tây',
        type_total: 20,
    },
    {
        type_name: 'Quần JEAN',
        type_total: 20,
    },


]