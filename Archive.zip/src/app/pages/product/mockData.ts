export const data = [
    {
        image: 'https://images.unsplash.com/photo-1487222477894-8943e31ef7b2?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=852&q=80',
        title: 'Fashion',
        subtitle: 'SHOP ALL',
        link: 'fashion'
    },
    {
        image: 'https://images.unsplash.com/photo-1539185441755-769473a23570?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1651&q=80',
        title: 'Shoes',
        subtitle: 'SHOP ALL',
        link: ''
    },
    {
        image: 'https://images.unsplash.com/photo-1582799905066-31e02579d8f0?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1650&q=80',
        title: 'Wallets',
        subtitle: 'SHOP ALL',
        link: ''
    },
    {
        image: 'https://images.unsplash.com/photo-1586232710888-675866d80ad2?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1334&q=80',
        title: 'Belts',
        subtitle: 'SHOP ALL',
        link: ''
    },
    {
        image: 'https://images.unsplash.com/photo-1542496658-e33a6d0d50f6?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1650&q=80',
        title: 'Belts',
        subtitle: 'SHOP ALL',
        link: ''
    },
    {
        image: 'https://images.unsplash.com/photo-1533462506003-13c20d204b58?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1650&q=80',
        title: 'Tie',
        subtitle: 'SHOP ALL',
        link: ''
    },
]